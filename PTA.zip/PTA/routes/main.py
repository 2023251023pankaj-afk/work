from datetime import date
import io
import os
import zipfile

from flask import Blueprint, current_app, jsonify, render_template, request, send_file, send_from_directory

from services.processor import build_insights, process_single, read_table, safe_filename, write_csv


main_blueprint = Blueprint("main", __name__)

ALLOWED_EXTENSIONS = (".csv", ".xlsx", ".xlsm")


@main_blueprint.route("/")
def index():
    return render_template("index.html")


@main_blueprint.route("/assets/<path:filename>")
def assets(filename):
    return send_from_directory(current_app.config["ASSETS_DIR"], filename)


@main_blueprint.route("/process-combined", methods=["POST"])
def process_combined():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "No files uploaded"}), 400
    if len(files) > 5:
        return jsonify({"error": "Maximum 5 files allowed"}), 400

    output_dir = current_app.config["OUTPUT_DIR"]
    for filename in os.listdir(output_dir):
        path = os.path.join(output_dir, filename)
        if os.path.isfile(path):
            os.remove(path)

    results = []
    for file in files:
        if not file.filename.lower().endswith(ALLOWED_EXTENSIONS):
            results.append({"filename": file.filename, "error": "Unsupported file type (only .csv, .xlsx, .xlsm)"})
            continue
        try:
            dataframe = read_table(file, file.filename)
        except Exception as error:
            results.append({"filename": file.filename, "error": f"Could not read file: {error}"})
            continue
        dataframe.columns = dataframe.columns.str.strip()

        menu_item_column = next((column for column in dataframe.columns if "Menu Item" in str(column)), None)
        if menu_item_column is None:
            results.append({"filename": file.filename, "error": "Menu Item column not found"})
            continue

        dataframe[menu_item_column] = dataframe[menu_item_column].astype(str).str.strip()
        menu_items = [item for item in dataframe[menu_item_column].unique() if item and item.lower() != "nan"]
        for item in menu_items:
            split_filename = f"{safe_filename(item)}.csv"
            split_file = io.BytesIO()
            write_csv(dataframe[dataframe[menu_item_column] == item], split_file)
            output_path, error = process_single(split_file, split_filename, output_dir)
            if error:
                results.append({"filename": split_filename, "error": error})
                continue
            results.append({"filename": split_filename, "output_filename": os.path.basename(output_path), "error": None})
    return jsonify(results)


@main_blueprint.route("/download/<output_filename>")
def download(output_filename):
    return send_from_directory(
        current_app.config["OUTPUT_DIR"],
        output_filename,
        mimetype="text/csv",
        as_attachment=True,
        download_name=output_filename,
    )


@main_blueprint.route("/download-all")
def download_all():
    output_dir = current_app.config["OUTPUT_DIR"]
    filenames = sorted(name for name in os.listdir(output_dir) if name.lower().endswith(".csv"))
    if not filenames:
        return "No output files found", 404
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename in filenames:
            archive.write(os.path.join(output_dir, filename), filename)
    buffer.seek(0)
    return send_file(buffer, mimetype="application/zip", as_attachment=True, download_name=f"PTA_Output_{date.today():%m_%d_%y}.zip")


@main_blueprint.route("/insights/<output_filename>")
def insights(output_filename):
    output_dir = current_app.config["OUTPUT_DIR"]
    if output_filename not in os.listdir(output_dir):
        return jsonify({"error": "No output file found"}), 400
    return jsonify(build_insights(os.path.join(output_dir, output_filename)))
