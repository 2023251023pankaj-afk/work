from datetime import date, datetime
import os
import re

import pandas as pd


# Output matches the final file format (Excel "CSV UTF-8"): UTF-8 with BOM, CRLF line endings.
OUTPUT_ENCODING = "utf-8-sig"
OUTPUT_LINE_TERMINATOR = "\r\n"
# Input CSVs are read as UTF-8 (a BOM, if present, is dropped); files saved from
# Excel as plain "CSV (Comma delimited)" fall back to Windows-1252.
INPUT_ENCODINGS = ("utf-8-sig", "cp1252")


def read_table(file, filename):
    """Read a CSV/Excel file with every cell kept as text."""
    if not filename.lower().endswith(".csv"):
        return pd.read_excel(file, dtype=str).fillna("")
    for encoding in INPUT_ENCODINGS:
        try:
            if hasattr(file, "seek"):
                file.seek(0)
            return pd.read_csv(file, dtype=str, keep_default_na=False, low_memory=False, encoding=encoding)
        except UnicodeDecodeError:
            if encoding == INPUT_ENCODINGS[-1]:
                raise


def safe_filename(value):
    """Replace characters Windows does not allow in file names."""
    return re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", str(value)).strip(" .") or "UNKNOWN"


def write_csv(dataframe, path):
    dataframe.to_csv(path, index=False, encoding=OUTPUT_ENCODING, lineterminator=OUTPUT_LINE_TERMINATOR)


def process_single(file, filename, output_dir):
    dataframe = read_table(file, filename)

    dataframe.columns = dataframe.columns.str.strip()
    column_names = {column.strip(): column for column in dataframe.columns}
    required_columns = ["Restaurant", "Effective Date", "Status", "Type", "Price"]
    missing_columns = [column for column in required_columns if column not in column_names]
    if missing_columns:
        return None, f"Missing required column(s): {', '.join(missing_columns)}"

    restaurant_column = column_names["Restaurant"]
    effective_date_column = column_names["Effective Date"]
    status_column = column_names["Status"]
    type_column = column_names["Type"]
    price_column = column_names["Price"]
    menu_item_column = column_names.get("Menu Item")
    menu_item = (
        str(dataframe[menu_item_column].dropna().iloc[0]).strip()
        if menu_item_column and not dataframe[menu_item_column].dropna().empty
        else "UNKNOWN"
    )
    output_filename = f"{safe_filename(menu_item)}_{date.today():%m_%d_%y}.csv"

    def convert_date(value):
        value = str(value).strip()
        if not value:
            return value
        try:
            return datetime.strptime(value, "%m/%d/%y").strftime("%m/%d/%y")
        except ValueError:
            try:
                return pd.to_datetime(value).strftime("%m/%d/%y")
            except Exception:
                return value

    # Convert each distinct date once; large files repeat the same few dates.
    unique_dates = dataframe[effective_date_column].unique()
    dataframe[effective_date_column] = dataframe[effective_date_column].map({value: convert_date(value) for value in unique_dates})
    eatin_dataframe = dataframe[dataframe[type_column].str.strip().str.lower() == "eatin"].copy()

    latest_dates = {}
    for _, row in eatin_dataframe.iterrows():
        restaurant = str(row[restaurant_column]).strip()
        date_value = str(row[effective_date_column]).strip()
        if date_value:
            try:
                parsed_date = datetime.strptime(date_value, "%m/%d/%y")
                latest_dates[restaurant] = max(latest_dates.get(restaurant, parsed_date), parsed_date)
            except ValueError:
                pass

    rows_to_keep = []
    for _, row in eatin_dataframe.iterrows():
        restaurant = str(row[restaurant_column]).strip()
        date_value = str(row[effective_date_column]).strip()
        if restaurant in latest_dates:
            try:
                if not date_value or datetime.strptime(date_value, "%m/%d/%y") != latest_dates[restaurant]:
                    continue
            except ValueError:
                continue
        rows_to_keep.append(row)

    filtered_dataframe = pd.DataFrame(rows_to_keep)
    output_rows = [
        {
            "STORE_CODE": str(row[restaurant_column]).strip(),
            "PRICE_EATIN": str(row[price_column]).strip(),
            "STATUS": str(row[status_column]).strip(),
            "EFFECTIVE_DATE": row[effective_date_column],
        }
        for _, row in filtered_dataframe.iterrows()
    ]
    output = pd.DataFrame(output_rows, columns=["STORE_CODE", "PRICE_EATIN", "STATUS", "EFFECTIVE_DATE"])
    output_path = os.path.join(output_dir, output_filename)
    write_csv(output, output_path)
    return output_path, None


def build_insights(output_path):
    output = pd.read_csv(output_path, dtype=str, keep_default_na=False, encoding=OUTPUT_ENCODING)
    total_stores = int(output["STORE_CODE"].nunique())
    status_counts = output["STATUS"].str.strip().str.upper().value_counts().to_dict()
    active_count = int(status_counts.get("ACTIVE", 0))
    inactive_count = int(status_counts.get("INACTIVE", 0))
    active_pct = round(active_count / total_stores * 100, 1) if total_stores else 0

    prices = pd.to_numeric(output["PRICE_EATIN"], errors="coerce")
    # "Not Priced" rows are expected: they are counted separately, not reported as problems.
    not_priced = output["PRICE_EATIN"].str.strip().str.lower() == "not priced"
    discrepancies = []
    checks = [
        (output["STORE_CODE"].str.contains(r"[^a-zA-Z0-9\-_]", na=False, regex=True), "Special characters in STORE_CODE"),
        (output["STATUS"].str.contains(r"[^a-zA-Z\s]", na=False, regex=True), "Special characters in STATUS"),
        ((output["EFFECTIVE_DATE"].str.strip() == "") & ~not_priced, "Blank EFFECTIVE_DATE on priced row"),
        (output.duplicated(subset=["STORE_CODE"], keep=False), "Duplicate STORE_CODE"),
        (prices.isna() & (output["PRICE_EATIN"].str.strip() != "") & ~not_priced, "Non-numeric PRICE_EATIN"),
    ]
    for mask, label in checks:
        if mask.any():
            discrepancies.append({"type": label, "count": int(mask.sum())})

    def is_invalid_date(value):
        value = str(value).strip()
        if not value:
            return False
        try:
            datetime.strptime(value, "%m/%d/%y")
            return False
        except ValueError:
            return True

    invalid_dates = output["EFFECTIVE_DATE"].apply(is_invalid_date)
    if invalid_dates.any():
        discrepancies.append({"type": "Invalid EFFECTIVE_DATE format", "count": int(invalid_dates.sum())})

    return {
        "total_stores": total_stores,
        "active": active_count,
        "inactive": inactive_count,
        "active_pct": active_pct,
        "not_priced": int(not_priced.sum()),
        "discrepancies": discrepancies,
    }