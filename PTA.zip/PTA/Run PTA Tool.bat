@echo off
setlocal
title PTA Automation Tool
cd /d "%~dp0"

set "PORT=5000"
set "VENV=.venv"

rem ---- Find Python (py launcher first, then python on PATH) ----
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY (
    where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo [ERROR] Python 3 was not found.
    echo Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
    pause
    exit /b 1
)

rem ---- First run: create a private environment and install requirements ----
if not exist "%VENV%\Scripts\python.exe" (
    echo First run: setting up the environment, this can take a few minutes...
    %PY% -m venv "%VENV%"
    if errorlevel 1 goto :setup_failed
    "%VENV%\Scripts\python.exe" -m pip install --upgrade pip >nul
)

rem ---- Install requirements on first run, or again if requirements.txt changed ----
fc /b requirements.txt "%VENV%\requirements.installed" >nul 2>&1
if errorlevel 1 (
    "%VENV%\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto :setup_failed
    copy /y requirements.txt "%VENV%\requirements.installed" >nul
)

echo.
echo  PTA Automation Tool is running at http://127.0.0.1:%PORT%
echo  Keep this window open while using the tool. Close it to stop.
echo.
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://127.0.0.1:%PORT%"
set "PTA_PORT=%PORT%"
"%VENV%\Scripts\python.exe" app.py
echo.
echo The tool has stopped.
pause
exit /b 0

:setup_failed
echo.
echo [ERROR] Setup failed. Check your internet connection and try again.
echo If it keeps failing, delete the "%VENV%" folder and run this file again.
pause
exit /b 1
