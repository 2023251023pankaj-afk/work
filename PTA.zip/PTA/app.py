import os

from flask import Flask

from routes.main import main_blueprint


BASE_DIR = os.path.dirname(__file__)


def create_app():
    app = Flask(__name__)
    app.config.update(
        OUTPUT_DIR=os.path.join(BASE_DIR, "Output"),
        ASSETS_DIR=os.path.join(BASE_DIR, "Assets"),
    )
    os.makedirs(app.config["OUTPUT_DIR"], exist_ok=True)
    app.register_blueprint(main_blueprint)
    return app


app = create_app()


if __name__ == "__main__":
    # Set PTA_DEBUG=1 for auto-reload while developing; off by default for everyday use.
    app.run(
        host="127.0.0.1",
        port=int(os.environ.get("PTA_PORT", "5000")),
        debug=os.environ.get("PTA_DEBUG") == "1",
    )